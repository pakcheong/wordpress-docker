<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/reclama-sidebar.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/reclama-sidebar.png');