<?php
//td_demo_media::add_image_to_media_gallery('td_pic_9', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/42.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/42.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_10', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/41.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/41.jpg');
