<?php
/**
 * Created by ra on 5/14/2015.
 */

// featured images
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/15.jpg');


