<?php
//td_demo_media::add_image_to_media_gallery('td_pic_7', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/44-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/44-3.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_8', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/43-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/43-3.jpg');