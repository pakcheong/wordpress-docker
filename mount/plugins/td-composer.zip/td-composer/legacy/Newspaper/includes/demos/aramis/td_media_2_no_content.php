<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/11/reclama-square-300x300-1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/reclama-square-300x300-1.jpg');