<?php

td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/art_blog_pro/media/1.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/art_blog_pro/media/2.jpg');

