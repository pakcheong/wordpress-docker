<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/mobile-bg4.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_11', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/login-bg.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_12', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/contact-img.jpg');
