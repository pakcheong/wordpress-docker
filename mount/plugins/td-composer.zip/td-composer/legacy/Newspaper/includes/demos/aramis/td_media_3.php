<?php
//td_demo_media::add_image_to_media_gallery('td_pic_9', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/37.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/37.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_10', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/36.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/36.jpg');
