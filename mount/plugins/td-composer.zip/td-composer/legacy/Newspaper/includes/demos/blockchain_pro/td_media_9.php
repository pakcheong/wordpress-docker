<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_31', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/be-in-crypto-logo.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_32', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/wsj-logo.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_33', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/money-logo.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_34', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/fintech-times-logo.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_35', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/Cision-logo.png');


