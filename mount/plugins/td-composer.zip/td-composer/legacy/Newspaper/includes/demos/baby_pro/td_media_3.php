<?php
td_demo_media::add_image_to_media_gallery('td_pic_7', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/7.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_8', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/8.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_9', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/9.jpg');
