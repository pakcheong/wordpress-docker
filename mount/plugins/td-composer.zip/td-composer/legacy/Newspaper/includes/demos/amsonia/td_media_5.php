<?php
//td_demo_media::add_image_to_media_gallery('td_pic_3', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/48.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/48.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_4', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/47.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/47.jpg');