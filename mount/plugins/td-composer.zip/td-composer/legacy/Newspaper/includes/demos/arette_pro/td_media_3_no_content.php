<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/mobile-bg3.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_18', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/background-asset6.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_11', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/login-bg.jpg');