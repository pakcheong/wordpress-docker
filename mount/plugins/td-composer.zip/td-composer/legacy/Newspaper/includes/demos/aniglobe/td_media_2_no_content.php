<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/reclama-wide-less-shadow.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/reclama-wide-less-shadow.png');