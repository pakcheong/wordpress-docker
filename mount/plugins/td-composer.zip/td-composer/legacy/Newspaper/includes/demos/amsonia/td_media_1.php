<?php
//td_demo_media::add_image_to_media_gallery('td_pic_1', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/50.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/50.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_2', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/49.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/49.jpg');
