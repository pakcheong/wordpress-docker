<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/11/404-image-500px.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/404-image-500px.png');