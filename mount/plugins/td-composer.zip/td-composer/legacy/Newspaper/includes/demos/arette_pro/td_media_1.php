<?php
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/40.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/39.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/38.jpg');

