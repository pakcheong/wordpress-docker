<?php

td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/15.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/14.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/13.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/12.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/11.jpg');


