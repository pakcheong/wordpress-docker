<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/xxx_aniglobe-pattern2_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/xxx_aniglobe-pattern2_xxx.png');