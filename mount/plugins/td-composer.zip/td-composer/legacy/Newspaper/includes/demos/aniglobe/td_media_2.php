<?php
//td_demo_media::add_image_to_media_gallery('td_pic_5', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/46-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/46-3.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_6', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/45-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/45-3.jpg');
