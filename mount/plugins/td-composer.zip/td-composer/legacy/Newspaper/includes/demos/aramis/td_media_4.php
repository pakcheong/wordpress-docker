<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/p3.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/p3.jpg');
//td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/1.jpg');
