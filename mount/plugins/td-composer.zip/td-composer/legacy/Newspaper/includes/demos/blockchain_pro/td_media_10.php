<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_36', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/Cointelegraph-logo.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_37', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/xxx_circles_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_38', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/develop.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_39', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/xxx_map_xxx.png');