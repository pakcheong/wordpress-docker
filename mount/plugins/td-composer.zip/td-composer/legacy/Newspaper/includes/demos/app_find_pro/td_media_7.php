<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/app_find_pro/media/g1.jpg');