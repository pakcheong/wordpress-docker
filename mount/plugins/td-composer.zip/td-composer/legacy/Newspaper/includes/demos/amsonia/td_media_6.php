<?php
//td_demo_media::add_image_to_media_gallery('td_pic_7', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/44.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/44.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_8', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/43.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/43.jpg');