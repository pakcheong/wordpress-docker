<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_21', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/ren.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_22', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/band.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_23', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/enterprise.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_24', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/dev.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_25', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/stake.png');


