<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/search-img2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/mobile-bg4.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/amberlight_pro/media/reclama-square.jpg');


