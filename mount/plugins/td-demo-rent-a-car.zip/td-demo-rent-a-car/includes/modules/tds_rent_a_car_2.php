<?php


class tds_rent_a_car_2 extends td_module
{

    function __construct($post_data_array, $module_atts = array())
    {
        //run the parrent constructor
        parent::__construct($post_data_array, $module_atts);
    }

    function render($shortcode_class = '', $style_class = '')
    {
        ob_start();

        $hide_image = $this->get_shortcode_att('hide_image', '', $style_class);
        $image_size = $this->get_shortcode_att('image_size', '', $style_class);
        $category_position = $this->get_shortcode_att('modules_category', '', $style_class);
        $btn_title = $this->get_shortcode_att('btn_title', '', $style_class);
        $title_length = $this->get_shortcode_att('mc1_tl', '', $style_class);
        $title_tag = $this->get_shortcode_att('mc1_title_tag', '', $style_class);
        $author_photo = $this->get_shortcode_att('author_photo', '', $style_class);
        $excerpt_length = $this->get_shortcode_att('mc1_el', '', $style_class);
        $excerpt_position = $this->get_shortcode_att('excerpt_middle', '', $style_class);
        $modified_date = $this->get_shortcode_att('show_modified_date', '', $style_class);
        $time_ago = $this->get_shortcode_att('time_ago', '', $style_class);
        $time_ago_add_txt = $this->get_shortcode_att('time_ago_add_txt', '', $style_class);
        $time_ago_txt_pos = $this->get_shortcode_att('time_ago_txt_pos', '', $style_class);
        $hide_audio = $this->get_shortcode_att('hide_audio', '', $style_class);

        $hide_author_date = '';

        $hide_cat = '';
        $hide_label = '';
        $hide_author = '';
        $hide_date = '';
        $hide_rev = '';
        $hide_com = '';
        $hide_excerpt = '';
        $hide_btn = '';

        if (!empty($shortcode_class)) {
            $hide_cat = $this->get_shortcode_att('show_cat', '', $style_class);
            $hide_label = $this->get_shortcode_att('modules_extra_cat', '', $style_class);
            $hide_author = $this->get_shortcode_att('show_author', '', $style_class);
            $hide_date = $this->get_shortcode_att('show_date', '', $style_class);
            $hide_rev = $this->get_shortcode_att('show_review', '', $style_class);
            $hide_com = $this->get_shortcode_att('show_com', '', $style_class);
            $hide_excerpt = $this->get_shortcode_att('show_excerpt', '', $style_class);
            $hide_btn = $this->get_shortcode_att('show_btn', '', $style_class);

            // when to hide
            if ($hide_cat == 'none') {
                $hide_cat = 'hide';
            }
            if ($hide_author == 'none') {
                $hide_author = 'hide';
            }
            if ($hide_date == 'none') {
                $hide_date = 'hide';
            }
            if ($hide_rev == 'none') {
                $hide_rev = 'hide';
            }
            if ($hide_com == 'none') {
                $hide_com = 'hide';
            }
            if ($hide_excerpt == 'none') {
                $hide_excerpt = 'hide';
            }
            if ($hide_btn == 'none') {
                $hide_btn = 'hide';
            }

            if ($hide_author == 'hide' && $hide_date == 'hide' && ($hide_rev == 'hide' || $this->get_review() == '') && $hide_com == 'hide' && $author_photo == '' && $hide_label == 'hide') {
                $hide_author_date = 'hide';
            }
        }

        if (empty($image_size)) {
            $image_size = 'td_696x0';
        }
        if (empty($btn_title)) {
            $btn_title = 'Read more';
        }

        $extra_cat = '';

        if ($hide_label != 'hide') {
            $td_post_theme_settings = td_util::get_post_meta_array($this->post->ID, 'td_post_theme_settings');
            $td_custom_cat_name = '';
            $td_custom_cat_name_url = '#';
//            var_dump($td_post_theme_settings);
            if (!empty($td_post_theme_settings['td_custom_cat_name'])) {
                //we have a custom category selected
                $td_custom_cat_name = $td_post_theme_settings['td_custom_cat_name'];
                if (!empty($td_post_theme_settings['td_custom_cat_name_url'])) {
                    $td_custom_cat_name_url = $td_post_theme_settings['td_custom_cat_name_url'];
                }
                $extra_cat = '<a href="' . $td_custom_cat_name_url . '" class="td-post-category td-post-extra-category">' . $td_custom_cat_name . '</a>';
            }
        }

        $excerpt = '<div class="td-excerpt">';
        $excerpt .= $this->get_excerpt($excerpt_length);
        $excerpt .= '</div>';


        $additional_classes_array = array('tdb_module_loop');
        $additional_classes_array = apply_filters('td_composer_module_exclusive_class', $additional_classes_array, $this->post);

        $h_effect = $this->get_shortcode_att('h_effect', '', $style_class);
        if ($h_effect != '') {
            $additional_classes_array[] = 'td-h-effect-' . $h_effect;
        }

        ?>
        <style>
            .td-price {
                color: #E6E8FA;
                padding-left: 280px;
                margin-top: -30px;
                font-size: 20px;
            }

            .td-free-cancelation {
                color: #E6E8FA;
                font-size: 15px;
                margin-top: 25px;
            }

            .td-seats {
                color: #E6E8FA;
                margin-top: 25px;
                display: inline-block;
                width: 20%;
            }

            .td-seats svg {
                width: 15px;
                height: auto;
                fill: #E6E8FA;
            }

            .td-doors {
                color: #E6E8FA;
                margin-top: 25px;
                display: inline-block;
                width: 20%;
            }

            .td-doors svg {
                width: 15px;
                height: auto;
                stroke: #E6E8FA;
            }

            .td-ac {
                color: #E6E8FA;
                margin-top: 25px;
                display: inline-block;
                width: 20%;
            }

            .td-ac svg {
                width: 15px;
                height: auto;
                fill: #E6E8FA;
            }

            .td-transmission {
                color: #E6E8FA;
                margin-top: 25px;
                display: inline-block;
                width: 20%;
            }

            .td-transmission svg {
                width: 15px;
                height: auto;
                stroke: #E6E8FA;
            }

            .td-cartype {
                color: #E6E8FA;
                margin-top: 25px;
                font-size: 15px;
                display: inline-block;
                width: 30%;
            }

            .td-carcode {
                color: #E6E8FA;
                margin-top: 25px;
                font-size: 15px;
                display: inline-block;
                width: 30%;
            }

            .td-rating {
                color: #E6E8FA;
                margin-top: 25px;
            }

            .td-rating .td-user-rev-star-half, .td-rating .td-user-rev-star-full {
                color: #f65648;
            }

            .td-rating .td-user-rev-star-empty {
                color: #E6E8FA;
            }

        </style>
        <div class="<?php echo $this->get_module_classes($additional_classes_array); ?>">
            <div class="td-module-container td-category-pos-<?php echo esc_attr($category_position) ?>">
                <?php if ($hide_image == '') { ?>
                    <div class="td-image-container">
                        <?php if ($category_position == 'image' && $hide_cat != 'hide') {
                            echo $this->get_category();
                        } ?>
                        <?php echo $this->get_image($image_size, true); ?>
                        <?php echo $this->get_video_duration(); ?>
                    </div>
                <?php } ?>

                <div class="td-module-meta-info">
                    <?php if ($hide_label == 'above') {
                        echo $extra_cat;
                    } ?>
                    <?php if ($category_position == 'above' && $hide_cat != 'hide') {
                        echo $this->get_category();
                    } ?>

                    <?php echo $this->get_title($title_length, $title_tag); ?>
                    <div class="td-price">
                        $<?php echo $this->show_custom_field_value('price'); ?>/Day
                    </div>
                    <div class="td-free-cancelation">&#10003 Free cancellation</div>
                    <div class="td-seats">
                        <svg viewBox="0 0 24 24" width="1em" height="1em">
                            <path d="M16.5 6a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0zM18 6A6 6 0 1 0 6 6a6 6 0 0 0 12 0zM3 23.25a9 9 0 1 1 18 0 .75.75 0 0 0 1.5 0c0-5.799-4.701-10.5-10.5-10.5S1.5 17.451 1.5 23.25a.75.75 0 0 0 1.5 0z"></path>
                        </svg> <?php echo $this->show_custom_field_value('seats'); ?> seats
                    </div>
                    <div class="td-doors">
                        <svg id="Layer_1_1_" style="enable-background:new 0 0 64 64;" version="1.1" viewBox="0 0 64 64"
                             xml:space="preserve" xmlns="http://www.w3.org/2000/svg"
                             xmlns:xlink="http://www.w3.org/1999/xlink"><g>
                                <path d="M14,1C6.832,1,1,6.832,1,14v43h40.627C41.232,58.606,41,60.274,41,62v1h22V42v-1V1H14z M51,17H39v16   h12v2H9V15c0-3.309,2.691-6,6-6h36V17z M51,31h-6v-2h-2v2h-2V19h2v8h2v-8h6c3.309,0,6,2.691,6,6S54.309,31,51,31z M57.484,29.668   L61,32.481v5.668l-5.332-6.665C56.366,30.979,56.979,30.366,57.484,29.668z M3,55V14C3,7.935,7.935,3,14,3h47v26.919l-2.546-2.037   C58.802,26.987,59,26.017,59,25c0-3.719-2.555-6.845-6-7.737V7H15c-4.411,0-8,3.589-8,8v22h46v-4.263   c0.301-0.078,0.596-0.171,0.883-0.283l6.887,8.608C52.186,41.564,44.986,47.228,42.225,55H3z M61,61H43.026   C43.531,51.318,51.318,43.531,61,43.026V61z"
                                      style="fill:#3F3A34;"/>
                                <path d="M24,41h-8.021c-0.939-1.246-2.416-2-3.979-2c-2.757,0-5,2.243-5,5s2.243,5,5,5   c1.563,0,3.041-0.754,3.979-2H24c1.654,0,3-1.346,3-3S25.654,41,24,41z M24,45h-9.13l-0.289,0.497C14.033,46.438,13.068,47,12,47   c-1.654,0-3-1.346-3-3s1.346-3,3-3c1.068,0,2.033,0.562,2.581,1.503L14.87,43H24c0.551,0,1,0.448,1,1S24.551,45,24,45z"
                                      style="fill:#3F3A34;"/>
                                <rect height="2" style="fill:#3F3A34;" width="2" x="15" y="11"/>
                                <rect height="2" style="fill:#3F3A34;" width="20" x="19" y="11"/>
                            </g></svg> <?php echo $this->show_custom_field_value('doors'); ?> doors
                    </div>
                    <div class="td-ac">
                        <svg height="512" viewBox="0 0 512 512" width="512" xmlns="http://www.w3.org/2000/svg"><title/>
                            <path d="M461,349l-34-19.64a89.53,89.53,0,0,1,20.94-16,22,22,0,0,0-21.28-38.51,133.62,133.62,0,0,0-38.55,32.1L300,256l88.09-50.86a133.46,133.46,0,0,0,38.55,32.1,22,22,0,1,0,21.28-38.51,89.74,89.74,0,0,1-20.94-16l34-19.64A22,22,0,1,0,439,125l-34,19.63a89.74,89.74,0,0,1-3.42-26.15A22,22,0,0,0,380,96h-.41a22,22,0,0,0-22,21.59A133.61,133.61,0,0,0,366.09,167L278,217.89V116.18a133.5,133.5,0,0,0,47.07-17.33,22,22,0,0,0-22.71-37.69A89.56,89.56,0,0,1,278,71.27V38a22,22,0,0,0-44,0V71.27a89.56,89.56,0,0,1-24.36-10.11,22,22,0,1,0-22.71,37.69A133.5,133.5,0,0,0,234,116.18V217.89L145.91,167a133.61,133.61,0,0,0,8.52-49.43,22,22,0,0,0-22-21.59H132a22,22,0,0,0-21.59,22.41A89.74,89.74,0,0,1,107,144.58L73,125a22,22,0,1,0-22,38.1l34,19.64a89.74,89.74,0,0,1-20.94,16,22,22,0,1,0,21.28,38.51,133.62,133.62,0,0,0,38.55-32.1L212,256l-88.09,50.86a133.62,133.62,0,0,0-38.55-32.1,22,22,0,1,0-21.28,38.51,89.74,89.74,0,0,1,20.94,16L51,349a22,22,0,1,0,22,38.1l34-19.63a89.74,89.74,0,0,1,3.42,26.15A22,22,0,0,0,132,416h.41a22,22,0,0,0,22-21.59A133.61,133.61,0,0,0,145.91,345L234,294.11V395.82a133.5,133.5,0,0,0-47.07,17.33,22,22,0,1,0,22.71,37.69A89.56,89.56,0,0,1,234,440.73V474a22,22,0,0,0,44,0V440.73a89.56,89.56,0,0,1,24.36,10.11,22,22,0,0,0,22.71-37.69A133.5,133.5,0,0,0,278,395.82V294.11L366.09,345a133.61,133.61,0,0,0-8.52,49.43,22,22,0,0,0,22,21.59H380a22,22,0,0,0,21.59-22.41A89.74,89.74,0,0,1,405,367.42l34,19.63A22,22,0,1,0,461,349Z"/>
                        </svg>
                        A/C <?php echo $this->show_custom_field_value('ac'); ?>
                    </div>
                    <div class="td-transmission">
                        <svg viewBox="0 0 24 24" width="1em" height="1em">
                            <path d="M1.5 6.75v-3a.75.75 0 0 0-1.5 0v3a.75.75 0 0 0 1.5 0zm2.85-.45l-2.25-3a.75.75 0 1 0-1.2.9l2.25 3a.75.75 0 1 0 1.2-.9zm18.9 13.95h-3L21 21v-.75A2.25 2.25 0 0 1 23.25 18l-.75-.75v6a.75.75 0 0 0 1.5 0v-6a.75.75 0 0 0-.75-.75 3.75 3.75 0 0 0-3.75 3.75V21c0 .414.336.75.75.75h3a.75.75 0 0 0 0-1.5zM18.024 2.056A.75.75 0 1 1 18.75 3v1.5a.75.75 0 1 1-.722.95.75.75 0 1 0-1.446.4A2.25 2.25 0 1 0 18.75 3c-1 0-1 1.5 0 1.5a2.25 2.25 0 1 0-2.174-2.832.75.75 0 0 0 1.448.388zM12 18.75a.75.75 0 0 1 1.5 0c0 .315-.107.622-.304.868l-2.532 3.163A.75.75 0 0 0 11.25 24h3a.75.75 0 0 0 0-1.5h-3l.586 1.219 2.532-3.164c.41-.513.632-1.15.632-1.805a2.25 2.25 0 0 0-4.5 0 .75.75 0 0 0 1.5 0zM8.25 1.5H9v5.25a.75.75 0 0 0 1.5 0V1.5A1.5 1.5 0 0 0 9 0h-.75a.75.75 0 0 0 0 1.5zm0 6h3a.75.75 0 0 0 0-1.5h-3a.75.75 0 0 0 0 1.5zm-6-7.5H.75A.75.75 0 0 0 0 .75v3c0 .414.336.75.75.75h1.5a2.25 2.25 0 0 0 0-4.5zm0 1.5a.75.75 0 0 1 0 1.5H.75l.75.75v-3l-.75.75h1.5zm8.25 11.25v-3a.75.75 0 0 0-1.5 0v3a.75.75 0 0 0 1.5 0zm1.5 0v1.5a.75.75 0 0 0 1.5 0v-1.5a.75.75 0 0 0-1.5 0zm7.5 0v-3a.75.75 0 0 0-1.5 0v3a.75.75 0 0 0 1.5 0zm3 1.5A2.25 2.25 0 0 0 20.25 12h-15A2.25 2.25 0 0 1 3 9.75a.75.75 0 0 0-1.5 0 3.75 3.75 0 0 0 3.75 3.75h15a.75.75 0 0 1 .75.75.75.75 0 0 0 1.5 0z"></path>
                        </svg> <?php echo $this->show_custom_field_value('transmission'); ?>
                    </div>
                    <div class="td-cartype">
                        <?php echo $this->show_custom_field_value('cartype'); ?>
                    </div>
                    <div class="td-carcode">
                        CAR CODE: <?php echo $this->show_custom_field_value('car_code'); ?>
                    </div>
                    <div class="td-rating">
                        <?php echo $this->show_user_ratings_stars("", "", "", true); ?>
                    </div>
                    <?php if ($excerpt_position == 'yes' && $hide_excerpt != 'hide') {
                        echo $excerpt;
                    } ?>

                    <?php if (($category_position == '' && $hide_cat != 'hide') || $hide_author_date != 'hide') { ?>
                        <div class="td-editor-date">
                            <?php if ($hide_label == '') {
                                echo $extra_cat;
                            } ?>
                            <?php if ($category_position == '' && $hide_cat != 'hide') {
                                echo $this->get_category();
                            } ?>

                            <?php if ($hide_author_date != 'hide') { ?>
                                <span class="td-author-date">
                                    <?php if ($author_photo != '') {
                                        echo $this->get_author_photo();
                                    } ?>
                                    <?php if ($hide_author != 'hide') {
                                        echo $this->get_author(true);
                                    } ?>
                                    <?php if ($hide_date != 'hide') {
                                        echo $this->get_date($modified_date, true, $time_ago, $time_ago_add_txt, $time_ago_txt_pos);
                                    } ?>
                                    <?php if ($hide_rev != 'hide') {
                                        echo $this->get_review();
                                    } ?>
                                    <?php if ($hide_com != 'hide') {
                                        echo $this->get_comments();
                                    } ?>
                                </span>
                            <?php } ?>
                        </div>
                    <?php } ?>

                    <?php if ($excerpt_position == '' && $hide_excerpt != 'hide') {
                        echo $excerpt;
                    } ?>

                    <?php if ($hide_audio == '') {
                        echo $this->get_audio_embed();
                    } ?>

                    <?php if ($hide_btn != 'hide') { ?>
                        <div class="td-read-more">
                            <a href="<?php echo $this->href; ?>"><?php echo __td($btn_title, TD_THEME_NAME); ?></a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <?php return ob_get_clean();
    }
}
